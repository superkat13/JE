#!/usr/bin/env bash
set -euo pipefail

SDK_ROOT="${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}"
CMDLINE_ZIP="commandlinetools-linux-14742923_latest.zip"
CMDLINE_URL="https://dl.google.com/android/repository/$CMDLINE_ZIP"

mkdir -p "$SDK_ROOT/cmdline-tools"

if [ ! -x "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]; then
  TMP_DIR="$(mktemp -d)"
  echo "Downloading Android command-line tools..."
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail "$CMDLINE_URL" -o "$TMP_DIR/$CMDLINE_ZIP"
  elif command -v wget >/dev/null 2>&1; then
    wget "$CMDLINE_URL" -O "$TMP_DIR/$CMDLINE_ZIP"
  else
    echo "curl or wget is required."
    exit 1
  fi

  unzip -q "$TMP_DIR/$CMDLINE_ZIP" -d "$TMP_DIR"
  rm -rf "$SDK_ROOT/cmdline-tools/latest"
  mkdir -p "$SDK_ROOT/cmdline-tools/latest"
  shopt -s dotglob
  mv "$TMP_DIR/cmdline-tools"/* "$SDK_ROOT/cmdline-tools/latest/"
  rm -rf "$TMP_DIR"
fi

export ANDROID_SDK_ROOT="$SDK_ROOT"
export ANDROID_HOME="$SDK_ROOT"
export PATH="$SDK_ROOT/cmdline-tools/latest/bin:$SDK_ROOT/platform-tools:$PATH"

yes | sdkmanager --licenses >/dev/null || true

sdkmanager \
  "platform-tools" \
  "platforms;android-36" \
  "build-tools;36.0.0" \
  "ndk;28.2.13676358" \
  "cmake;3.22.1"

echo
echo "Android SDK ready at $SDK_ROOT"
echo "Add this to your shell profile if needed:"
echo "export ANDROID_SDK_ROOT=\"$SDK_ROOT\""
echo "export ANDROID_HOME=\"$SDK_ROOT\""
echo "export PATH=\"\$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:\$ANDROID_SDK_ROOT/platform-tools:\$PATH\""
