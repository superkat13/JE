#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include <thread>
#include <android/log.h>
#include "llama.h"

static llama_model * g_model = nullptr;
static llama_context * g_ctx = nullptr;
static std::mutex g_mutex;
static std::string g_last_error = "Model not loaded";
static bool g_backend_initialized = false;

#define LOG_TAG "JE-LLAMA"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static void set_error(const std::string & message) {
    g_last_error = message;
    LOGE("%s", message.c_str());
}

static void release_model_locked() {
    if (g_ctx) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
}

static std::string token_to_piece(const llama_vocab * vocab, llama_token token, bool special = false) {
    std::string piece;
    piece.resize(32);

    int n_chars = llama_token_to_piece(vocab, token, piece.data(), static_cast<int>(piece.size()), 0, special);
    if (n_chars < 0) {
        piece.resize(static_cast<size_t>(-n_chars));
        n_chars = llama_token_to_piece(vocab, token, piece.data(), static_cast<int>(piece.size()), 0, special);
    }

    if (n_chars <= 0) {
        return {};
    }

    piece.resize(static_cast<size_t>(n_chars));
    return piece;
}

static bool decode_tokens(llama_context * ctx, const std::vector<llama_token> & tokens, int32_t & n_past) {
    if (tokens.empty()) {
        set_error("No tokens to decode");
        return false;
    }

    llama_batch batch = llama_batch_init(static_cast<int32_t>(tokens.size()), 0, 1);

    for (int32_t i = 0; i < static_cast<int32_t>(tokens.size()); ++i) {
        batch.token[i] = tokens[static_cast<size_t>(i)];
        batch.pos[i] = n_past + i;
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0;
        batch.logits[i] = (i == static_cast<int32_t>(tokens.size()) - 1) ? 1 : 0;
    }
    batch.n_tokens = static_cast<int32_t>(tokens.size());

    const int rc = llama_decode(ctx, batch);
    llama_batch_free(batch);

    if (rc != 0) {
        set_error("llama_decode failed with code " + std::to_string(rc));
        return false;
    }

    n_past += static_cast<int32_t>(tokens.size());
    return true;
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_je_core_JeLlamaBridge_initModelNative(JNIEnv * env, jobject /*thiz*/, jstring path) {
    std::lock_guard<std::mutex> lock(g_mutex);

    if (!path) {
        set_error("Model path is null");
        return JNI_FALSE;
    }

    const char * raw_path = env->GetStringUTFChars(path, nullptr);
    if (!raw_path) {
        set_error("Could not read model path string");
        return JNI_FALSE;
    }

    std::string model_path(raw_path);
    env->ReleaseStringUTFChars(path, raw_path);

    if (model_path.empty()) {
        set_error("Model path is empty");
        return JNI_FALSE;
    }

    if (!g_backend_initialized) {
        llama_backend_init();
        g_backend_initialized = true;
    }

    release_model_locked();

    LOGI("Loading model: %s", model_path.c_str());

    llama_model_params model_params = llama_model_default_params();
    g_model = llama_model_load_from_file(model_path.c_str(), model_params);

    if (!g_model) {
        set_error("Failed to load model from: " + model_path);
        return JNI_FALSE;
    }

    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = 1024;
    ctx_params.n_batch = 512;
    ctx_params.n_threads = std::max(2u, std::min(4u, std::thread::hardware_concurrency()));
    ctx_params.n_threads_batch = ctx_params.n_threads;

    g_ctx = llama_init_from_model(g_model, ctx_params);
    if (!g_ctx) {
        release_model_locked();
        set_error("Failed to create llama context");
        return JNI_FALSE;
    }

    g_last_error.clear();
    LOGI("Model loaded successfully");
    return JNI_TRUE;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_je_core_JeLlamaBridge_generateNative(JNIEnv * env, jobject /*thiz*/, jstring prompt) {
    std::lock_guard<std::mutex> lock(g_mutex);

    if (!g_model || !g_ctx) {
        set_error("Generate called before model was loaded");
        return env->NewStringUTF("...");
    }

    if (!prompt) {
        set_error("Prompt is null");
        return env->NewStringUTF("...");
    }

    const char * input = env->GetStringUTFChars(prompt, nullptr);
    if (!input) {
        set_error("Could not read prompt");
        return env->NewStringUTF("...");
    }

    std::string prompt_str(input);
    env->ReleaseStringUTFChars(prompt, input);

    if (prompt_str.empty()) {
        return env->NewStringUTF("...");
    }

    const llama_vocab * vocab = llama_model_get_vocab(g_model);
    if (!vocab) {
        set_error("Model vocabulary is unavailable");
        return env->NewStringUTF("...");
    }

    llama_kv_self_clear(g_ctx);

    int32_t token_count = -llama_tokenize(
        vocab,
        prompt_str.c_str(),
        static_cast<int32_t>(prompt_str.size()),
        nullptr,
        0,
        true,
        true
    );

    if (token_count <= 0) {
        set_error("Prompt tokenization failed");
        return env->NewStringUTF("...");
    }

    std::vector<llama_token> tokens(static_cast<size_t>(token_count));
    int32_t actual = llama_tokenize(
        vocab,
        prompt_str.c_str(),
        static_cast<int32_t>(prompt_str.size()),
        tokens.data(),
        token_count,
        true,
        true
    );

    if (actual <= 0) {
        set_error("Prompt tokenization returned no tokens");
        return env->NewStringUTF("...");
    }

    tokens.resize(static_cast<size_t>(actual));

    int32_t n_past = 0;
    if (!decode_tokens(g_ctx, tokens, n_past)) {
        return env->NewStringUTF("...");
    }

    std::string output;
    constexpr int max_new_tokens = 96;

    for (int i = 0; i < max_new_tokens; ++i) {
        const float * logits = llama_get_logits_ith(g_ctx, -1);
        if (!logits) {
            set_error("Could not read logits");
            break;
        }

        const int32_t vocab_size = llama_vocab_n_tokens(vocab);
        llama_token best = 0;
        float best_logit = logits[0];

        for (int32_t token = 1; token < vocab_size; ++token) {
            if (logits[token] > best_logit) {
                best_logit = logits[token];
                best = token;
            }
        }

        if (llama_vocab_is_eog(vocab, best)) {
            break;
        }

        const std::string piece = token_to_piece(vocab, best, false);
        if (!piece.empty()) {
            output += piece;
        }

        std::vector<llama_token> next_token = { best };
        if (!decode_tokens(g_ctx, next_token, n_past)) {
            break;
        }
    }

    if (output.empty()) {
        output = "...";
    }

    g_last_error.clear();
    return env->NewStringUTF(output.c_str());
}

extern "C"
JNIEXPORT void JNICALL
Java_com_je_core_JeLlamaBridge_resetNative(JNIEnv * /*env*/, jobject /*thiz*/) {
    std::lock_guard<std::mutex> lock(g_mutex);
    release_model_locked();
    g_last_error = "Model reset";
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_je_core_JeLlamaBridge_lastNativeError(JNIEnv * env, jobject /*thiz*/) {
    std::lock_guard<std::mutex> lock(g_mutex);
    return env->NewStringUTF(g_last_error.c_str());
}
