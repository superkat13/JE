#include <jni.h>
#include <android/log.h>

#define LOG_TAG "JE-LLAMA-STUB"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_je_core_JeLlamaBridge_initModelNative(JNIEnv * env, jobject, jstring) {
    LOGI("Native fallback stub active. llama.cpp was not bundled at build time.");
    return JNI_FALSE;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_je_core_JeLlamaBridge_generateNative(JNIEnv * env, jobject, jstring) {
    return env->NewStringUTF("");
}

extern "C"
JNIEXPORT void JNICALL
Java_com_je_core_JeLlamaBridge_resetNative(JNIEnv *, jobject) {
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_je_core_JeLlamaBridge_lastNativeError(JNIEnv * env, jobject) {
    return env->NewStringUTF("This APK was built without llama.cpp. Run ./fetch_llama.sh and rebuild for local GGUF inference.");
}
