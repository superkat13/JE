package com.je.core

import android.util.Log
import java.io.File
import kotlin.concurrent.thread

object JeLlamaBridge {
    private const val TAG = "JE-LLAMA"

    private var libraryLoaded = false
    @Volatile private var ready = false
    @Volatile private var lastError = "Model not loaded"

    init {
        libraryLoaded = try {
            System.loadLibrary("je-llama")
            Log.i(TAG, "Native library loaded")
            true
        } catch (t: Throwable) {
            lastError = "Native library failed to load: ${t.message ?: t.javaClass.simpleName}"
            Log.e(TAG, lastError, t)
            false
        }
    }

    private external fun initModelNative(path: String): Boolean
    private external fun generateNative(prompt: String): String
    private external fun resetNative()
    private external fun lastNativeError(): String

    fun isReady(): Boolean = ready
    fun getLastError(): String = lastError

    @Synchronized
    fun loadModel(path: String): Boolean {
        ready = false

        if (!libraryLoaded) {
            Log.e(TAG, lastError)
            return false
        }

        val file = File(path)
        if (!file.exists() || !file.isFile) {
            lastError = "Model file not found: $path"
            Log.e(TAG, lastError)
            return false
        }

        if (!file.canRead()) {
            lastError = "Model file is not readable: $path"
            Log.e(TAG, lastError)
            return false
        }

        ready = try {
            Log.i(TAG, "Loading model: $path (${file.length()} bytes)")
            initModelNative(path)
        } catch (t: Throwable) {
            lastError = "Model init crashed: ${t.message ?: t.javaClass.simpleName}"
            Log.e(TAG, lastError, t)
            false
        }

        if (!ready) {
            lastError = safeNativeError("Failed to load model")
            Log.e(TAG, lastError)
        } else {
            lastError = ""
            Log.i(TAG, "Model loaded successfully")
        }

        return ready
    }

    fun run(prompt: String): String {
        if (!ready) return ""

        return try {
            val response = generateNative(prompt.trim())
            if (response == "...") "" else response
        } catch (t: Throwable) {
            lastError = "Generation failed: ${t.message ?: t.javaClass.simpleName}"
            Log.e(TAG, lastError, t)
            ""
        }
    }

    fun runAsync(prompt: String, onDone: (String) -> Unit, onError: (String) -> Unit) {
        thread(name = "JE-Inference") {
            try {
                onDone(run(prompt))
            } catch (t: Throwable) {
                val message = "Generation failed: ${t.message ?: t.javaClass.simpleName}"
                lastError = message
                onError(message)
            }
        }
    }

    fun streamText(text: String, onToken: (String) -> Unit, onDone: () -> Unit) {
        thread(name = "JE-Text-Streamer") {
            text.forEach { ch ->
                onToken(ch.toString())
                Thread.sleep(8)
            }
            onDone()
        }
    }

    fun reset() {
        try {
            if (libraryLoaded) resetNative()
        } catch (t: Throwable) {
            Log.e(TAG, "Native reset failed", t)
        }
        ready = false
    }

    private fun safeNativeError(fallback: String): String {
        return try {
            lastNativeError().takeIf { it.isNotBlank() } ?: fallback
        } catch (_: Throwable) {
            fallback
        }
    }
}
