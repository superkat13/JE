package com.je

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.AnimationUtils
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.je.core.JeLlamaBridge
import com.je.core.JeMemoryStore
import com.je.core.JeMind
import com.je.core.JeToolRouter
import com.je.core.JeVoice
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var statusText: TextView
    private lateinit var chatLogText: TextView
    private lateinit var typingText: TextView
    private lateinit var modelProgress: ProgressBar
    private lateinit var chatScroll: ScrollView
    private lateinit var inputText: EditText
    private lateinit var memory: JeMemoryStore
    private lateinit var tools: JeToolRouter
    private lateinit var gestureDetector: GestureDetector

    private val clock = SimpleDateFormat("h:mm a", Locale.US)
    private val chatBuffer = StringBuilder()
    private val prefs by lazy { getSharedPreferences("je_chat", Context.MODE_PRIVATE) }
    private var lowEndMode = false
    private var tone: ToneGenerator? = null

    private val audioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else setStatus("Microphone permission denied")
    }

    private val modelPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) {
            setStatus("Model selection cancelled")
            soundError()
            return@registerForActivityResult
        }

        beginBusy("Copying model into private storage...")
        thread(name = "JE-Model-Copy") {
            val result = copyModelToInternalStorage(uri)
            runOnUiThread {
                result.fold(
                    onSuccess = { modelFile -> loadModel(modelFile) },
                    onFailure = { error ->
                        endBusy("Failed to copy model: ${error.message}")
                        soundError()
                    }
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_JE)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        memory = JeMemoryStore(this)
        tools = JeToolRouter(this, memory)
        JeVoice.init(this)
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, 35)

        inputText = findViewById(R.id.inputText)
        statusText = findViewById(R.id.statusText)
        chatLogText = findViewById(R.id.chatLogText)
        typingText = findViewById(R.id.typingText)
        modelProgress = findViewById(R.id.modelProgress)
        chatScroll = findViewById(R.id.chatScroll)

        val sendButton = findViewById<Button>(R.id.sendButton)
        val micButton = findViewById<Button>(R.id.micButton)
        val loadModelButton = findViewById<Button>(R.id.loadModelButton)
        val dailyButton = findViewById<Button>(R.id.dailyButton)
        val clearButton = findViewById<Button>(R.id.clearButton)

        lowEndMode = detectLowEndMode()
        restoreChatHistory()

        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                val start = e1 ?: return false
                val dx = e2.x - start.x
                val dy = e2.y - start.y
                if (kotlin.math.abs(dx) < 140 || kotlin.math.abs(dx) < kotlin.math.abs(dy)) return false

                return if (dx > 0) {
                    hapticSoft()
                    requestVoice()
                    setStatus("Gesture: voice input")
                    true
                } else {
                    hapticSoft()
                    submitInput("daily")
                    setStatus("Gesture: daily check")
                    true
                }
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                hapticSoft()
                inputText.requestFocus()
                setStatus("Gesture: ready to type")
                return true
            }
        })

        chatScroll.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            false
        }

        wireButton(sendButton) { submitInput(inputText.text?.toString().orEmpty()) }
        wireButton(micButton) { requestVoice() }
        wireButton(loadModelButton) { modelPicker.launch("*/*") }
        wireButton(dailyButton) { submitInput("daily") }
        wireButton(clearButton) {
            memory.clear()
            chatBuffer.clear()
            chatLogText.text = "Memory cleared. JE ready.\n"
            saveChatHistory()
            setStatus("Memory cleared")
            soundConfirm()
        }

        inputText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitInput(inputText.text?.toString().orEmpty())
                true
            } else {
                false
            }
        }

        val existingModel = File(filesDir, "models/je_model.gguf")
        if (existingModel.exists() && !lowEndMode) {
            loadModel(existingModel)
        } else if (existingModel.exists()) {
            setStatus("Low-end mode enabled. Model autoload skipped; tap Model when ready.")
        } else {
            setStatus("Choose a GGUF model. JE can still save notes without one.")
        }

        if (lowEndMode) {
            appendSystemOnce("Low-end mode is active: voice and model loading stay manual to protect memory.")
        }
    }

    override fun onDestroy() {
        saveChatHistory()
        tone?.release()
        tone = null
        JeVoice.shutdown()
        super.onDestroy()
    }

    private fun wireButton(button: Button, action: () -> Unit) {
        button.setOnClickListener {
            hapticSoft()
            soundTap()
            action()
        }
    }

    private fun submitInput(raw: String) {
        val text = raw.trim()
        if (text.isBlank()) return

        inputText.setText("")
        appendChat("You", text, animate = true)

        val toolResult = tools.route(text)
        if (toolResult.handled) {
            streamAssistantMessage(toolResult.message, speak = true)
            return
        }

        beginTyping(if (JeLlamaBridge.isReady()) "JE is thinking..." else "No model loaded; using lightweight fallback")
        thread(name = "JE-Daily-Think") {
            val memoryContext = memory.contextForPrompt(text)
            val reply = if (JeLlamaBridge.isReady()) {
                JeMind.think(text, memoryContext)
            } else {
                JeMind.fallback(text, memoryContext)
            }

            if (text.length > 32 && !text.endsWith("?")) {
                memory.remember("Conversation: $text", importance = 1)
            }

            runOnUiThread {
                endTyping()
                streamAssistantMessage(reply, speak = true)
                setStatus(if (JeLlamaBridge.isReady()) "Ready" else "Ready without model")
            }
        }
    }

    private fun streamAssistantMessage(text: String, speak: Boolean) {
        beginTyping("JE is replying...")
        val started = StringBuilder()
        val prefix = "\nJE · ${clock.format(Date())}\n"
        chatBuffer.append(prefix)
        chatLogText.text = chatBuffer.toString()
        chatScroll.post { chatScroll.fullScroll(ScrollView.FOCUS_DOWN) }

        JeLlamaBridge.streamText(
            text = text,
            onToken = { token ->
                runOnUiThread {
                    if (started.isEmpty()) endTyping()
                    started.append(token)
                    chatLogText.text = chatBuffer.toString() + started.toString() + "▌"
                    chatLogText.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in))
                    chatScroll.post { chatScroll.fullScroll(ScrollView.FOCUS_DOWN) }
                }
            },
            onDone = {
                runOnUiThread {
                    chatBuffer.append(started.toString()).append("\n")
                    chatLogText.text = chatBuffer.toString()
                    saveChatHistory()
                    soundConfirm()
                    if (speak && !lowEndMode) JeVoice.speakSoft(text)
                }
            }
        )
    }

    private fun appendChat(who: String, text: String, animate: Boolean = false) {
        chatBuffer
            .append("\n")
            .append(who)
            .append(" · ")
            .append(clock.format(Date()))
            .append("\n")
            .append(text.trim())
            .append("\n")
        chatLogText.text = chatBuffer.toString()
        if (animate) chatLogText.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left))
        chatScroll.post { chatScroll.fullScroll(ScrollView.FOCUS_DOWN) }
        saveChatHistory()
    }

    private fun appendSystemOnce(text: String) {
        if (!chatBuffer.contains(text)) appendChat("System", text)
    }

    private fun requestVoice() {
        if (lowEndMode) {
            setStatus("Low-end mode: voice is manual. Tap Voice again if needed.")
        }

        val permission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
        if (permission == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startListening() {
        beginTyping("Listening...")
        JeVoice.listen(
            context = this,
            onText = { heard ->
                runOnUiThread {
                    endTyping()
                    setStatus("Heard voice input")
                    submitInput(heard)
                }
            },
            onError = { error ->
                runOnUiThread {
                    endTyping()
                    setStatus(error)
                    soundError()
                }
            }
        )
    }

    private fun loadModel(modelFile: File) {
        beginBusy("Loading model: ${modelFile.name}")
        thread(name = "JE-Model-Load") {
            val ok = JeLlamaBridge.loadModel(modelFile.absolutePath)
            runOnUiThread {
                if (ok) {
                    endBusy("Model loaded: ${modelFile.name}")
                    soundConfirm()
                } else {
                    endBusy(JeLlamaBridge.getLastError())
                    soundError()
                }
            }
        }
    }

    private fun beginBusy(text: String) {
        setStatus(text)
        modelProgress.visibility = View.VISIBLE
        hapticSoft()
    }

    private fun endBusy(text: String) {
        setStatus(text)
        modelProgress.visibility = View.GONE
    }

    private fun beginTyping(text: String) {
        setStatus(text)
        typingText.visibility = View.VISIBLE
        typingText.text = "JE is typing •••"
        typingText.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in))
    }

    private fun endTyping() {
        typingText.clearAnimation()
        typingText.visibility = View.GONE
    }

    private fun setStatus(text: String) {
        statusText.text = "Status: $text"
    }

    private fun hapticSoft() {
        val type = if (android.os.Build.VERSION.SDK_INT >= 30) {
            HapticFeedbackConstants.CONFIRM
        } else {
            HapticFeedbackConstants.VIRTUAL_KEY
        }
        window.decorView.performHapticFeedback(type)
    }

    private fun soundTap() {
        tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 45)
    }

    private fun soundConfirm() {
        tone?.startTone(ToneGenerator.TONE_PROP_ACK, 80)
    }

    private fun soundError() {
        tone?.startTone(ToneGenerator.TONE_PROP_NACK, 120)
    }

    private fun detectLowEndMode(): Boolean {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(info)
        val totalMb = info.totalMem / (1024L * 1024L)
        return info.isLowMemory || totalMb < 3500L
    }

    private fun saveChatHistory() {
        val obj = JSONObject()
            .put("chat", chatBuffer.toString())
            .put("updated", System.currentTimeMillis())
        prefs.edit().putString("history", obj.toString()).apply()
    }

    private fun restoreChatHistory() {
        val raw = prefs.getString("history", null)
        val restored = runCatching {
            raw?.let { JSONObject(it).optString("chat") }
        }.getOrNull()

        if (!restored.isNullOrBlank()) {
            chatBuffer.append(restored)
            chatLogText.text = restored
        } else {
            val starter = chatLogText.text.toString()
            chatBuffer.append(starter)
        }
    }

    private fun copyModelToInternalStorage(uri: Uri): Result<File> = runCatching {
        val selectedName = queryDisplayName(uri)
        val fileName = selectedName.takeIf { it.endsWith(".gguf", ignoreCase = true) } ?: "je_model.gguf"
        val modelDir = File(filesDir, "models").apply { mkdirs() }
        val destination = File(modelDir, fileName)

        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Could not open selected file" }
            destination.outputStream().use { output -> input.copyTo(output) }
        }

        if (destination.name != "je_model.gguf") {
            val canonical = File(modelDir, "je_model.gguf")
            destination.copyTo(canonical, overwrite = true)
            destination.delete()
            canonical
        } else {
            destination
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) {
                return cursor.getString(index) ?: "je_model.gguf"
            }
        }
        return "je_model.gguf"
    }
}
