package com.je.core

import java.util.LinkedHashMap

object JeMind {
    private const val MAX_CACHE = 32

    private val responseCache = object : LinkedHashMap<String, String>(MAX_CACHE, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
            return size > MAX_CACHE
        }
    }

    @Synchronized
    fun think(input: String, memoryContext: String = "", mode: String = "Daily"): String {
        val clean = input.trim()
        val cacheKey = "$mode|$memoryContext|$clean"

        responseCache[cacheKey]?.let { return it }

        val prompt = """
            You are JE, a private daily AI companion.
            Mode: $mode

            Rules:
            - Be calm, direct, and useful.
            - Prefer short answers unless the user asks for detail.
            - Use saved memory only when relevant.
            - Never pretend to have done something outside the app.
            - Suggest one clear next step when helpful.

            Saved memory:
            $memoryContext

            User:
            $clean

            JE:
        """.trimIndent()

        val response = JeLlamaBridge.run(prompt).trim().ifBlank {
            fallback(clean, memoryContext)
        }

        responseCache[cacheKey] = response
        return response
    }

    fun fallback(input: String, memoryContext: String = ""): String {
        return when {
            input.contains("plan", ignoreCase = true) ->
                "Plan: choose the outcome, list the next three actions, then do the first one now."
            input.contains("remember", ignoreCase = true) ->
                "Tell me what to remember using: remember <thing>."
            memoryContext.isNotBlank() && memoryContext != "No saved personal memories yet." ->
                "I found relevant memory. What do you want to do with it?"
            else ->
                "I’m ready. Give me one task, thought, or question."
        }
    }
}
