package com.je.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class JeMemoryItem(
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val importance: Int = 1
)

class JeMemoryStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("je_memory", Context.MODE_PRIVATE)
    private val dateFormat = SimpleDateFormat("MMM d, h:mm a", Locale.US)

    @Synchronized
    fun remember(text: String, importance: Int = 1) {
        val clean = text.trim()
        if (clean.isBlank()) return

        val items = loadMutable()
        items.add(JeMemoryItem(clean, System.currentTimeMillis(), importance.coerceIn(1, 5)))

        val trimmed = items
            .sortedWith(compareByDescending<JeMemoryItem> { it.importance }.thenByDescending { it.timestamp })
            .take(120)

        save(trimmed)
    }

    @Synchronized
    fun recent(limit: Int = 12): List<JeMemoryItem> {
        return loadMutable().sortedByDescending { it.timestamp }.take(limit)
    }

    @Synchronized
    fun search(query: String, limit: Int = 8): List<JeMemoryItem> {
        val terms = query.lowercase(Locale.US).split("\\s+".toRegex()).filter { it.length > 2 }
        if (terms.isEmpty()) return recent(limit)
        return loadMutable()
            .map { item -> item to terms.count { item.text.lowercase(Locale.US).contains(it) } }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<JeMemoryItem, Int>> { it.second }.thenByDescending { it.first.timestamp })
            .take(limit)
            .map { it.first }
    }

    @Synchronized
    fun clear() {
        prefs.edit().remove("items").apply()
    }

    fun contextForPrompt(query: String): String {
        val memories = search(query, 8)
        if (memories.isEmpty()) return "No saved personal memories yet."
        return memories.joinToString("\n") { "- ${dateFormat.format(Date(it.timestamp))}: ${it.text}" }
    }

    fun dailySummary(): String {
        val memories = recent(8)
        return if (memories.isEmpty()) {
            "No memory yet. Tell JE something to remember."
        } else {
            "Recent memory:\n" + memories.joinToString("\n") { "- ${it.text}" }
        }
    }

    private fun loadMutable(): MutableList<JeMemoryItem> {
        val raw = prefs.getString("items", "[]") ?: "[]"
        val array = JSONArray(raw)
        val result = mutableListOf<JeMemoryItem>()
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            result.add(
                JeMemoryItem(
                    text = obj.optString("text"),
                    timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                    importance = obj.optInt("importance", 1)
                )
            )
        }
        return result
    }

    private fun save(items: List<JeMemoryItem>) {
        val array = JSONArray()
        items.forEach {
            array.put(
                JSONObject()
                    .put("text", it.text)
                    .put("timestamp", it.timestamp)
                    .put("importance", it.importance)
            )
        }
        prefs.edit().putString("items", array.toString()).apply()
    }
}
