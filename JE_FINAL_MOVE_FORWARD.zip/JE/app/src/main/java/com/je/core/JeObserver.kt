package com.je.core

import android.os.Handler
import android.os.Looper

object JeObserver {
    private var lastPackage: String? = null
    private var lastSpeak = 0L
    private val history = mutableListOf<String>()
    private val handler = Handler(Looper.getMainLooper())

    private const val COOLDOWN_MS = 2500L

    fun onScreenEvent(pkg: String, content: String) {
        val now = System.currentTimeMillis()
        if (now - lastSpeak < COOLDOWN_MS) return

        history.add(pkg)
        if (history.size > 5) history.removeAt(0)

        if (history.count { it == pkg } > 3) {
            JeVoice.speakSoft("You're circling.")
            lastSpeak = now
            return
        }

        val lower = content.lowercase()
        val shouldThink = content.length > 150 || lower.contains("error") || lower.contains("failed")

        if (shouldThink) {
            Thread {
                val response = JeMind.think(content, pkg)
                handler.post { JeVoice.speakSoft(response) }
            }.start()
            lastSpeak = now
        } else if (pkg != lastPackage) {
            JeVoice.speakSoft("Different screen.")
            lastSpeak = now
        }

        lastPackage = pkg
    }

    fun onNotification(pkg: String, title: String, text: String) {
        val body = "$title $text".lowercase()
        if (Regex("""\b\d{4,8}\b""").containsMatchIn(body)) {
            JeVoice.speakSoft("A code just came through.")
        } else if (pkg.contains("message", ignoreCase = true)) {
            JeVoice.speakSoft("Something came in.")
        }
    }
}
