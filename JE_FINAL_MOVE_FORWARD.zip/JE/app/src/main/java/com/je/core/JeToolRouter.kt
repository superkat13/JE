package com.je.core

import android.content.Context
import java.util.Locale

class JeToolRouter(private val context: Context, private val memory: JeMemoryStore) {

    data class ToolResult(
        val handled: Boolean,
        val message: String
    )

    fun route(input: String): ToolResult {
        val clean = input.trim()
        val lower = clean.lowercase(Locale.US)

        return when {
            lower.startsWith("remember ") -> {
                val value = clean.removePrefix("remember").trim()
                memory.remember(value, importance = 3)
                ToolResult(true, "Remembered: $value")
            }

            lower.startsWith("note ") || lower.startsWith("notes ") -> {
                val value = clean.substringAfter(" ").trim()
                memory.remember("Note: $value", importance = 2)
                ToolResult(true, "Saved note: $value")
            }

            lower == "memory" || lower == "show memory" -> {
                ToolResult(true, memory.dailySummary())
            }

            lower == "summarize today" || lower == "daily" || lower == "daily check" -> {
                ToolResult(true, buildDailyCheck())
            }

            lower.startsWith("open ") -> {
                val appName = clean.removePrefix("open").trim()
                ToolResult(true, "App opening is intentionally manual in this personal build. Ask me to add a specific app shortcut for: $appName")
            }

            else -> ToolResult(false, "")
        }
    }

    private fun buildDailyCheck(): String {
        return """
            Daily check:
            1. Pick one important task.
            2. Clear one small friction point.
            3. Keep the next action visible.

            ${memory.dailySummary()}
        """.trimIndent()
    }
}
