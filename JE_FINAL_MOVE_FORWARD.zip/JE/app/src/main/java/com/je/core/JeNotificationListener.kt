package com.je.core

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JeNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getString("android.title") ?: ""
        val text = extras.getString("android.text") ?: ""
        JeObserver.onNotification(sbn.packageName, title, text)
    }
}
