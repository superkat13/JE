package com.je.core

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JeAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        JeVoice.init(this)
        JeVoice.speakSoft("Ready when you are.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val pkg = event?.packageName?.toString() ?: return
        val text = extract(root)
        JeObserver.onScreenEvent(pkg, text)
    }

    override fun onInterrupt() {}

    private fun extract(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        val builder = StringBuilder()
        node.text?.let { builder.append(it).append(" ") }
        for (i in 0 until node.childCount) {
            builder.append(extract(node.getChild(i)))
        }
        return builder.toString()
    }
}
